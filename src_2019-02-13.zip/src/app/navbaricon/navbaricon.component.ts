import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbaricon',
  templateUrl: './navbaricon.component.html',
  styleUrls: ['./navbaricon.component.css']
})
export class NavbariconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
