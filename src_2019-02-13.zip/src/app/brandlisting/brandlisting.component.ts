import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brandlisting',
  templateUrl: './brandlisting.component.html',
  styleUrls: ['./brandlisting.component.css']
})
export class BrandlistingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
