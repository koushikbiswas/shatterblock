import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-influencerlisting',
  templateUrl: './influencerlisting.component.html',
  styleUrls: ['./influencerlisting.component.css']
})
export class InfluencerlistingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
