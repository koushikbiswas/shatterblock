import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldfooter',
  templateUrl: './oldfooter.component.html',
  styleUrls: ['./oldfooter.component.css']
})
export class OldfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
