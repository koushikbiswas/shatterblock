import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trendingmodels',
  templateUrl: './trendingmodels.component.html',
  styleUrls: ['./trendingmodels.component.css']
})
export class TrendingmodelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
