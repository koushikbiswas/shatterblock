import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-models',
  templateUrl: './our-models.component.html',
  styleUrls: ['./our-models.component.css']
})
export class OurModelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
