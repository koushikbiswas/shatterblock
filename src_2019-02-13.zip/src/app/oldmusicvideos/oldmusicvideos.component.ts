import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldmusicvideos',
  templateUrl: './oldmusicvideos.component.html',
  styleUrls: ['./oldmusicvideos.component.css']
})
export class OldmusicvideosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
