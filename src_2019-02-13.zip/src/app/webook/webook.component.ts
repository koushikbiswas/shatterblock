import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webook',
  templateUrl: './webook.component.html',
  styleUrls: ['./webook.component.css']
})
export class WebookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
