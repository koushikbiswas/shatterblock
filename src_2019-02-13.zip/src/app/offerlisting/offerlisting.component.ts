import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offerlisting',
  templateUrl: './offerlisting.component.html',
  styleUrls: ['./offerlisting.component.css']
})
export class OfferlistingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
