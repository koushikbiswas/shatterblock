import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-musicvideos',
  templateUrl: './musicvideos.component.html',
  styleUrls: ['./musicvideos.component.css']
})
export class MusicvideosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
