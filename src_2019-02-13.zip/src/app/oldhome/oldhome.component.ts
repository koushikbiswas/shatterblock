import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldhome',
  templateUrl: './oldhome.component.html',
  styleUrls: ['./oldhome.component.css']
})
export class OldhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
