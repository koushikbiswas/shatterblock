import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldheader',
  templateUrl: './oldheader.component.html',
  styleUrls: ['./oldheader.component.css']
})
export class OldheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
