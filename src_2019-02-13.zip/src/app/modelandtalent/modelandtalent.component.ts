import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modelandtalent',
  templateUrl: './modelandtalent.component.html',
  styleUrls: ['./modelandtalent.component.css']
})
export class ModelandtalentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
