import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-musicdivision',
  templateUrl: './musicdivision.component.html',
  styleUrls: ['./musicdivision.component.css']
})
export class MusicdivisionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
