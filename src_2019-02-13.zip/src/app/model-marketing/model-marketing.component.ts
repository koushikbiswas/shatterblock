import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-marketing',
  templateUrl: './model-marketing.component.html',
  styleUrls: ['./model-marketing.component.css']
})
export class ModelMarketingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
